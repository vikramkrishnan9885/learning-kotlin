rootProject.name = "spring-getting-started"
