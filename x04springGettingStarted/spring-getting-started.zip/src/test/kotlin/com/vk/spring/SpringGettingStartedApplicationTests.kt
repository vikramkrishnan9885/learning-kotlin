package com.vk.spring

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringGettingStartedApplicationTests {

	@Test
	fun contextLoads() {
	}

}
