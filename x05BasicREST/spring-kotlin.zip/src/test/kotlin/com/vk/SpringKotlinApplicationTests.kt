package com.vk

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class SpringKotlinApplicationTests {

	@Test
	fun contextLoads() {
	}

}
