package com.vk.security

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ShiroApplication

fun main(args: Array<String>) {
	runApplication<ShiroApplication>(*args)
}
