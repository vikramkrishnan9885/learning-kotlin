package com.vk.kotlinlearning

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class RibbonClientApplication

fun main(args: Array<String>) {
	runApplication<RibbonClientApplication>(*args)
}
